<?php

$paginaname = 'Buy Bitcoin';


?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php 
			
			include("@/header.php");

			if (!($user->hasMembership($odb))) {
				header('location: index.php');
				die();
			}

			?>
				
					</script>
                    <div id="page-content">
					
                       
				
<div class="col-xs-12">
Hello members, we are writing this article due the massive requests. So there it is, an simple fast way to buy bitcoins :)
<br>
<br>
<br>
<div class="panel-group" id="accordion">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" data-parent="#accordion" href="#collapse1">
        What is Bitcoin and how to use it?</a>
      </h4>
    </div>
    <div id="collapse1" class="panel-collapse collapse in">
      <div class="panel-body">
	Bitcoin is cryptocurrency introduced in 2009 by a person (or a group of) the pseudonym Satoshi Nakamoto.<p>
	This currency is completely anonymous and can't be blocked/banned/limited by anyone.<p>

	<strong>CREATE BTC WALLET</strong><p>

	<strong>Website - Recommended for beginners</strong><p>
	
	https://coinbase.com/ - Recomended | Good to buy BTC in accepted countries<p>
	https://blockchain.info/

	<p><p>
	<strong>VERY EASY METHOD TO BUY BITCOIN WITH PAYPAL - YOU DON'T BUY BECAUSE YOU DON'T WANT! PAYPAL IS BAD AS FUCK!</strong><p>
	Tutorial: https://www.youtube.com/watch?v=3sKcbgWDaJ8<p>
	Website: http://www.wesellcrypto.com
<p>
	<p><strong>WHERE I CAN BUY WITH PAYPAL / OTHER METHODS?</strong><p>
https://wesellcrypto.com/limits - PayPal to BitCoin<p>
https://localbitcoins.com/ - Local Exchnage<p>
https://www.virwox.com/ - https://www.youtube.com/watch?v=0Bgs0OEQv7Q
</div>
    </div>
  </div>

    
          </div>
	</div>

		<?php include("@/script.php"); ?>
<!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/58432a0c8a20fc0cac4bcca0/default';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
    </body>
</html>