<?php

$paginaname = 'VPN';

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->

<head>
	<meta charset="utf-8">
	<title>Network Stresser | Homepage</title>
	<meta http-equiv="X-UA-Compatible" content="IE=Edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="">
	<meta name="description" content="">
<!--

Designed by CyberForce

-->
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/animate.min.css">
	<link rel="stylesheet" href="css/et-line-font.css">
	<link rel="stylesheet" href="css/nivo-lightbox.css">
	<link rel="stylesheet" href="css/nivo_themes/default/default.css">
	<link rel="stylesheet" href="css/style.css">
	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,500' rel='stylesheet' type='text/css'>
<link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
        <script src="js/vendor/modernizr-2.8.3.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
</head>
<body data-spy="scroll" data-target=".navbar-collapse" data-offset="50">
<section id="pricing">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 text-center">
				<div class="section-title">
					<strong>LIGHTNING VPN'S</strong>
					<h1 class="heading bold">OUR PRICING</h1>
					<hr>
				</div>
			</div>
			<div class="col-md-4 col-sm-6">
				<div class="plan plan-one wow bounceIn" data-wow-delay="0.3s">
					<div class="plan_title">
						<i class="icon-compass medium-icon"></i>
						<h3>Bronze</h3>
						<h2>$5 <span>/month</span></h2>
					</div>
					<ul>
                    	<li>Bandwith: No limit</li>
						<li>Devices: 1</li>
						<li>Length: 1 Month</li>
                        <li>Support: 24/7</li>
					</ul>
					<a href="https://network-stresser.pw/hub/purchase.php" class="smoothScroll btn btn-danger">GET IT NOW!</a>
				</div>
			</div>
			<div class="col-md-4 col-sm-6">
				<div class="plan plan-two wow bounceIn" data-wow-delay="0.3s">
					<div class="plan_title">
						<i class="icon-desktop medium-icon"></i>
						<h3>Gold</h3>
						<h2>$8 <span>/month</span></h2>
					</div>
					<ul>
						<li>Bandwith: No limit</li>
						<li>Devices: 2</li>
						<li>Length: 1 Month</li>
                        <li>Support: 24/7</li>
					</ul>
					<a href="https://network-stresser.pw/hub/purchase.php" class="smoothScroll btn btn-danger">GET IT NOW!</a>
				</div>
			</div>
			<div class="col-md-4 col-sm-6">
				<div class="plan plan-three wow bounceIn" data-wow-delay="0.3s">
					<div class="plan_title">
						<i class="icon-cloud medium-icon"></i>
						<h3>Diamond</h3>
						<h2>$13 <span>/month</span></h2>
					</div>
					<ul>
						<li>Bandwith: No limit</li>
						<li>Devices: 4</li>
						<li>Length: 1 Month</li>
                        <li>Support: 24/7</li>
					</ul>
					<a href="https://network-stresser.pw/hub/purchase.php" class="smoothScroll btn btn-danger">GET IT NOW!</a>
				</div><b><center>Chat with our Live Support to buy a VPN.</center></b>
			</div>
		</div>
	</div>		
</section>

		</div>
	</div>
</section>


<p><p>

												
												
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

                     <? // NO BORRAR LOS TRES DIVS! ?>
               </div>
               </div>
             
          </div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/smoothscroll.js"></script>
<script src="js/isotope.js"></script>
<script src="js/imagesloaded.min.js"></script>
<script src="js/nivo-lightbox.min.js"></script>
<script src="js/jquery.backstretch.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/custom.js"></script>
    </body>
</html>