<script>window.location.replace("tickets_1.php");</script>
