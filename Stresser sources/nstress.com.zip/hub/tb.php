<?php

$paginaname = 'Test Boot';

?>
<!DOCTYPE html>
<!--[if IE 9]>         <html class="no-js lt-ie10"> <![endif]-->
<!--[if gt IE 9]><!--> <html class="no-js"> <!--<![endif]-->
			<?php include("@/header.php"); ?>
				

                    <div id="page-content">
            
                        <div class="row">
						
                          
						<div class="col-sm-12">
				
 
							<div class="widget">
								<div class="widget-content widget-content-mini themed-background-dark text-light-op">
								<span class="pull-right text-muted">Using 100Mb/s</span>
								<i class="fa fa-send"></i> <b>Test Boot</b>
								</div>
								
								<div class="widget-content">
									<form action="" method="POST">
								<div align="center">
                                    									<br>
								</div>
									<center>Thanks for register on our stresser!<br></center>
									<center><br></center>
									<center>Your plan expired and you are unable to use free panel.<br></center>
									<center>If you want a Plan, check our purchase area.<br><br></center>
									<center>Register another account if you want to have access to free stress.<br></center>
								</form>
									</div>
								
							</div>
						</div>
						 
						</div>
					</div>	
                     <? // NO BORRAR LOS TRES DIVS! ?>
               </div>
               </div>
             
          </div>

		<?php include("@/script.php"); ?>
    </body>
</html>