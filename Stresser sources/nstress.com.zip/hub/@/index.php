<?

header('Location: ../');

?>