	<footer id="page-footer" class="opacity-0" style="opacity: 1;">
	<center>
<div class="content py-20 font-size-xs clearfix">
<div class="text-center">
<div class="container">
<div class="float-right">
Created with <i class="fa fa-heart text-pulse text-danger"></i> by <a class="font-w600" href="#" target="_blank"> R̷e̷l̷a̷j̷o̷ | </a>

<a class="font-w600" href="netsource.pw" target="_blank">Netsource.pw Best Stresser Source</a> © <span class="js-year-copy">2020</span>
</div>
</div>
</div>
</div>
</center>
	
  <!-- Bootstrap core JavaScript-->
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/popper.min.js"></script>
  <script src="../assets/js/bootstrap.min.js"></script>
	
 <!-- simplebar js -->
  <script src="../assets/plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="../assets/js/sidebar-menu.js"></script>
  <!-- loader scripts -->
  <script src="../assets/js/jquery.loading-indicator.js"></script>
  <!-- Custom scripts -->
  <script src="../assets/js/app-script.js"></script>
  <!-- Chart js -->
  
  <script src="../assets/plugins/Chart.js/Chart.min.js"></script>
  <!-- Vector map JavaScript -->
  <script src="../assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
  <script src="../assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- Easy Pie Chart JS -->
  <script src="../assets/plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
  <!-- Sparkline JS -->
  <script src="../assets/plugins/sparkline-charts/jquery.sparkline.min.js"></script>
  <script src="../assets/plugins/jquery-knob/excanvas.js"></script>
  <script src="../assets/plugins/jquery-knob/jquery.knob.js"></script>