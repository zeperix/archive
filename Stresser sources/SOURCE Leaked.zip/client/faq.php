<?php 

 
session_start();
$page = "Faq";
include 'header.php';
    $runningrip = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
	$slotsx = $odb->query("SELECT COUNT(*) FROM `api` WHERE `slots`")->fetchColumn(0);
	$load    = round($runningrip / $slotsx * 100, 2);	
	
		
?>

<!-- page wrapper start -->
        <div class="wrapper">
            <div class="container-fluid">

                <div class="page-title-box">
                    <div class="row align-items-center">
                
                        <div class="col-sm-6">
              <ol class="breadcrumb">
                  <li class="breadcrumb-item active">Oblivion / Faq</li>
                            </ol>
                
                        </div>
                        <div class="col-sm-6">
                
                            <div class="float-right d-none d-md-block">
                                <div class="dropdown">
                                    
                                </div>
                            </div>
                
                        </div>
                    </div>
                </div>
                <!-- end row -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row justify-content-center mb-5">
                                    <div class="col-lg-5">
                                        <div class="text-center faq-title pt-4 pb-4">
                                            <div class="pt-3 pb-3">
                                                <i class="ti-comments text-primary h3"></i>
                                            </div>
                                            <h5>Can't find what you are looking for?</h5>
                                            <p class="text-muted">If you cant find what you are looking for, please contact us immediately.</p>
                                            
                                            <a href="support.php" class="btn btn-primary m-t-10 mr-1 waves-effect waves-light">Ticket us</a>
                                        </div>
                                    </div>
                                </div>
                                <!-- end row -->

                                <div class="row justify-content-center">
                                    <div class="col-lg-5">
                                        <h5 class="mt-0 font-18 mb-4"><i class="ti-agenda text-primary mr-2"></i> General Questions</h5>
                                        <div class="accordion" id="accordionExample">
                                            <div class="card mb-0">
                                                <a data-toggle="collapse" href="#collapseOne" class="faq" aria-expanded="true" aria-controls="collapseOne">
                                                    <div class="card-header text-light" id="headingOne">
                                                        <h6 class="m-0 faq-question">Can I share my account?</h6>
                                                    </div>
                                                </a>
                
                                                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                    <div class="card-body">
                                                        <p class="text-muted mb-0 faq-ans"> We do not allow account shares. If you do, you will be banned for unlimited.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- collapse one end -->
                
                                            <div class="card mb-0">
                                                <a data-toggle="collapse" href="#collapseTwo" class="faq collapsed" aria-expanded="false" aria-controls="collapseTwo">
                                                    <div class="card-header text-light" id="headingTwo">
                                                        <h6 class="m-0 faq-question">Can I try it before I buy it?</h6>
                                                    </div>
                                                </a>
                                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                                    <div class="card-body">
                                                        <p class="text-muted mb-0 faq-ans">We cant do this because every network requires a cost. We also kept the prices very reasonable.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- collapse two end -->
                
                                            
                                        </div>
                                        <!-- end accordian -->
                                    </div>

                                    <div class="col-lg-5 offset-lg-1">
                                        <h5 class="mt-0 font-18 mb-4"><i class="ti-bookmark-alt text-primary mr-2"></i> Pricing  & Plans</h5>
                                        <div class="accordion" id="accordionExample2">
                                            <div class="card mb-0">
                                                <a data-toggle="collapse" href="#collapseFive" class="faq" aria-expanded="true" aria-controls="collapseFive">
                                                    <div class="card-header text-light" id="headingFive">
                                                        <h6 class="m-0 faq-question">Can I Refund?</h6>
                                                    </div>
                                                </a>
                
                                                <div id="collapseFive" class="collapse show" aria-labelledby="headingFive" data-parent="#accordionExample2">
                                                    <div class="card-body">
                                                        <p class="text-muted mb-0 faq-ans">We do not refund, thanks for your understanding.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- collapse one end -->
                
                                            <div class="card mb-0">
                                                <a data-toggle="collapse" href="#collapseSix" class="faq collapsed" aria-expanded="false" aria-controls="collapseSix">
                                                    <div class="card-header text-light" id="headingSix">
                                                        <h6 class="m-0 faq-question">When will be active after making a payment?</h6>
                                                    </div>
                                                </a>
                                                <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample2">
                                                    <div class="card-body">
                                                        <p class="text-muted mb-0 faq-ans">Your plan will be added within 1-2 hours at most.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- collapse two end -->
                
                                            <div class="card mb-0">
                                                <a data-toggle="collapse" href="#collapseSeven" class="faq collapsed" aria-expanded="false" aria-controls="collapseSeven">
                                                    <div class="card-header text-light" id="headingSeven">
                                                        <h6 class="m-0 faq-question">Is there a limit to using?</h6>
                                                    </div>
                                                </a>
                                                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample2">
                                                    <div class="card-body">
                                                        <p class="text-muted mb-0 faq-ans">When you buy a plan, you can use unlimited service during the month or days.</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <!-- collapse three end -->
                                        </div>
                                        <!-- end accordian -->
                                    </div>
                                </div>
                                <!-- end row -->

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->
                
            </div>
            <!-- end container-fluid -->

        </div>
        <!-- page wrapper end -->

        <!-- Footer -->
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">
                        2019 � Veltrix <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Themesbrand</span>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->

<?php include('footer.php'); ?>
      