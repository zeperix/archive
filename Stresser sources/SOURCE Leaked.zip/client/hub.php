<?php 

session_start();
$page = "Hub";
include 'header.php';
   $runningrip = $odb->query("SELECT COUNT(*) FROM `logs` WHERE `time` + `date` > UNIX_TIMESTAMP() AND `stopped` = 0")->fetchColumn(0);
 $slotsx = $odb->query("SELECT COUNT(*) FROM `api` WHERE `slots`")->fetchColumn(0);
 $load    = round($runningrip / $slotsx * 100, 2);	
 
   
?>
<?php 
							if (!$user->hasMembership($odb)) {
               header('location: purchase.php');
                die();
                }
							?>

<div class="wrapper">
  <div class="container-fluid">
    <div class="row">
    <div class="col-md-12">
    </div>
    </div>


  <div class="container-fluid">
    <div class="page-title-box">
      <div class="row align-items-center">
        <div class="col-sm-12">
                              <ol class="breadcrumb">
                  <li class="breadcrumb-item active">Oblivion / Stresser</li>
            </ol>
        </div>
      </div>
    </div>
    <div id="attackalert" style="display:none"></div>
    
    <div class="row">
      <div class="col-md-4">
       <div class="card">
         <div class="card-body">
         <h4 class="mt-0 header-title mb-4">Attack Hub.</h4>

            <form class="form-horizontal" method="post" onsubmit="return false;">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="form-material floating">
                                        <label for="host"><i class="si si-arrow-right text-danger"></i> Host</label>
                                            <input type="text" class="form-control" id="host" name="host" placeholder="Host">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="form-material floating">
                                          <label for="port">Port</label>
                                            <input type="text" class="form-control" id="port" name="port" placeholder="Port">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="form-material floating">
                                        <label for="time">Time</label>

                                            <input type="text" class="form-control" id="time" name="time" placeholder="Time">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-xs-12">
                                    <div>
                                        <label for="method"><i class="si si-energy text-danger"></i> Method</label>
                                        <select class="form-control" style="border: 1px solid #4c535c;" id="method" name="method">
                                           	<optgroup label="LAYER4" style="color:white;">
														<?php
															$SQLGetLogs = $odb->query("SELECT * FROM `methods` WHERE `type` = 'layer4' ORDER BY `id` ASC");
															while ($getInfo = $SQLGetLogs->fetch(PDO::FETCH_ASSOC)) {
																$name     = $getInfo['name'];
																$fullname = $getInfo['fullname'];
																echo '<option value="' . $name . '">' . $fullname . '</option>';
															}
														?>
														</optgroup>
															<optgroup label="LAYER7" style="color:white;">
														<?php
															$SQLGetLogs = $odb->query("SELECT * FROM `methods` WHERE `type` = 'layer7' ORDER BY `id` ASC");
															while ($getInfo = $SQLGetLogs->fetch(PDO::FETCH_ASSOC)) {
																$name     = $getInfo['name'];
																$fullname = $getInfo['fullname'];
																echo '<option value="' . $name . '">' . $fullname . '</option>';
															}
														?>
														</optgroup>
											 			
														      <optgroup label="VIP " style="color:white;">
														<?php
															$SQLGetLogs = $odb->query("SELECT * FROM `methods` WHERE `type` = 'vip' ORDER BY `id` ASC");
															while ($getInfo = $SQLGetLogs->fetch(PDO::FETCH_ASSOC)) {
																$name     = $getInfo['name'];
																$fullname = $getInfo['fullname'];
																echo '<option value="' . $name . '">'. $fullname . '</option>';
															}
														?>
														</optgroup>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label">Servers </label>
                                <input class="form-control" id="totalservers" style="border: 1px solid #4c535c;"type="text" value="1" name="totalservers" data-bts-min="1" data-bts-max="10" data-bts-init-val="" data-bts-step="1" data-bts-decimal="0" data-bts-step-interval="100" data-bts-force-step-divisibility="round" data-bts-step-interval-delay="500" data-bts-prefix="" data-bts-postfix="" data-bts-prefix-extra-class="" data-bts-postfix-extra-class="" data-bts-booster="true" data-bts-boostat="10" data-bts-max-boosted-step="false" data-bts-mousewheel="true" data-bts-button-down-class="btn btn-primary btn-trans waves-effect w-md waves-info m-b-5" data-bts-button-up-class="btn btn-success"> 
                               <small style="margin-top: 10px"> Max Servers Per Attack:
                                <?php 
								
							$SQL = $odb->prepare("SELECT `aserv` FROM `users` WHERE `users`.`ID` = :id");
			$SQL ->execute(array(':id' => $_SESSION['ID']));
			$aserv = $SQL -> fetchColumn(0);
			
								$SQLGetTime = $odb->prepare("SELECT `plans`.`totalservers` FROM `plans` LEFT JOIN `users` ON `users`.`membership` = `plans`.`ID` WHERE `users`.`ID` = :id");
				    $SQLGetTime->execute(array(
				        ':id' => $_SESSION['ID']
				    ));
				    $totalservers = $SQLGetTime->fetchColumn(0); echo $totalservers+$aserv; 
					?>
          </small>
                            </div>
							    <div class="form-group">
      <div class="col-xs-12">
          <div>
            <label for="method">VIP</label>
                              <select class="form-control" style="border: 1px solid #4c535c;" id="vip" name="vip">
          <option value="0">No</option>
          <option value="1">Yes</option>
          </select>
          </div>
      </div>
  </div>

                <div class="form-group m-b-0">
                    <div class="col-sm-12" style="padding: 0">
      <button class="btn btn-primary btn-block btn-trans waves-effect w-md waves-info m-b-5" onclick="attack()" id="hit" type="button"> <i class="fa fa-bolt"></i> Send! </button>
      
                    </div>
                </div>
  
            </form>
         </div>
       </div>
      </div>
      <div class="col-md-8">
      <div class="card">
        <div class="card-body">
            <h4 class="mt-0 header-title mb-4">Manage Attacks</h4>
            <div class="table-responsive" id="attacksdiv">
                <table class="table table-hover">
                   
                    <thead>
                        <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Target</th>
                        <th scope="col">Method</th>
                        <th scope="col">Servers</th>
                        <th scope="col">Network</th>
                        <th scope="col">Expries</th>
                        <th scope="col">Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
      </div>
    </div>
  </div>
</div>
<script
  src="https://code.jquery.com/jquery-3.4.1.min.js"
  integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
  crossorigin="anonymous"></script>
<script>
$(function(){
  attacks();

$('#hit').on('click',function(){
  attack()
});
$(document).on('click','.rere',function(){
  var id = $(this).attr('renew-id');
  renew(id)
});
$(document).on('click','.stop',function(){
  var id = $(this).attr('stop-id');
  stop(id)
});
function attacks() {
    document.getElementById("attacksdiv").style.display = "none";
    var xmlhttp;
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    } else {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.onreadystatechange = function() {
  

        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
          document.getElementById("attacksdiv").innerHTML = xmlhttp.responseText;
      document.getElementById("attacksdiv").style.display = "inline-block";
            document.getElementById("attacksdiv").style.display = "inline-block";
            document.getElementById("attacksdiv").style.width = "100%";
            eval(document.getElementById("ajax").innerHTML);
        }
    }
    xmlhttp.open("GET", "includes/attacks.php", true);
    xmlhttp.send();
}


function attack() {
                    var host = $('#host').val();
                    var time = $('#time').val();
                    var port = $('#port').val();
                    var method = $('#method').val();
                    var totalservers = $('#totalservers').val();
					var vip=$('#vip').val();
                    document.getElementById("attackalert").style.display = "none";
                    //ocument.getElementById("attackloader").style.display="inline";
                    var xmlhttp;
                    if (window.XMLHttpRequest) {
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function() {
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            document.getElementById("attackalert").innerHTML = xmlhttp.responseText;
                            //document.getElementById("attackloader").style.display="none";
                            document.getElementById("attackalert").style.display = "inline";

                        }
                    }
                    xmlhttp.open("GET", "includes/hub.php?type=start" + "&host=" + host + "&port=" + port + "&time=" + time + "&method=" + method + "&totalservers=" + totalservers + "&vip=" + vip, true);
                    xmlhttp.send();
                    attacks();
                  
                }

                function renew(id) {
                    document.getElementById("attackalert").style.display = "none";
                    var xmlhttp;
                    if (window.XMLHttpRequest) {
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function() {
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            document.getElementById("attackalert").innerHTML = xmlhttp.responseText;
                            document.getElementById("attackalert").style.display = "inline";
                            if (xmlhttp.responseText.search("Attack sent to Host") != -1) {
                                attacks();
                            }
                        }
                    }
                    xmlhttp.open("GET", "includes/hub.php?type=renew" + "&id=" + id, true);
                    xmlhttp.send();
                    attacks();
                }

                function stop(id) {
                    document.getElementById("attackalert").style.display = "none";
                    var xmlhttp;
                    if (window.XMLHttpRequest) {
                        xmlhttp = new XMLHttpRequest();
                    } else {
                        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                    }
                    xmlhttp.onreadystatechange = function() {
                        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                            document.getElementById("attackalert").innerHTML = xmlhttp.responseText;
                            document.getElementById("attackalert").style.display = "inline";
                            if (xmlhttp.responseText.search("SUCCESS") != -1) {
								
                                attacks();
                            }
                        }
                    }
                    xmlhttp.open("GET", "includes/hub.php?type=stop" + "&id=" + id, true);
                    xmlhttp.send();
                }

})

</script>

<script>
</script>

<?php require 'footer.php' ?>