

<?php
    ob_start();
    $nukflpw = "Session";
    require_once "rip/configuration.php";
    require_once "rip/init.php";
   
    if (empty(${$qifyotruip})) {
    
    }
    if ($settings["cloudflare_set"] == "1") {
        $ip = $_SERVER["HTTP_CF_CONNECTING_IP"];
    } else {
        $ip = $_SERVER["REMOTE_ADDR"];
    }
    $checksession = $odb->prepare("SELECT * FROM users WHERE id = ?");
    $checksession->execute(array(
        $_SESSION["ID"]
    ));
    while ($session = $checksession->fetch(PDO::FETCH_ASSOC)) {
        $qvuulgqd    = "dif";
        $lastsession = $session["lastact"];
        $dif         = time() - $lastsession;
        if (${$qvuulgqd} < 7200) {
        } else {
            header("location: login.php?session=rip");
            session_destroy();
            die();
        }
    }
    if (!($user->LoggedIn()) || !($user->notBanned($odb))) {
        header("location: logout.php");
        die();
    }
    $update = $odb->prepare("UPDATE users SET lastact = ? WHERE ID = ?");
    $update->execute(array(
        time(),
        $_SESSION["ID"]
    ));
    $SQLCheckBlacklistRIPX = $odb->prepare("SELECT COUNT(*) FROM `ipbanned` WHERE `IP` = :ip");
    $SQLCheckBlacklistRIPX->execute(array(
        ":ip" => $ip
    ));
    $countBlacklistRIPX = $SQLCheckBlacklistRIPX->fetchColumn(0);
    function generateRandomKeysRiPx($length = 50)
    {
        $xwqcbtv      = "i";
        $characters   = "0123456789abcdefghijklmnopqrstuvwxyz";
        $randomString = "";
        for ($i = 0; $i < $length; ${$xwqcbtv}++) {
            $randomString .= $characters[rand(0, strlen($characters) - 1)];
        }
        return $randomString;
    }
    ${$nukflpw} = generateRandomKeysRiPx();
    if ($countBlacklistRIPX > 0) {
        header("location: autoban.php?" . $ip . "=" . $Session . "");
        die();
    }
    $SQL = $odb->prepare("SELECT `balance`, `username` FROM `users` WHERE `username` = :usuario");
    $SQL->execute(array(
        ":usuario" => $_SESSION["username"]
    ));
    $getinfo = $SQL->fetch(PDO::FETCH_ASSOC);
    $balance = $getinfo["balance"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<script data-ad-client="ca-pub-6279802118653175" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
  <title><?php echo $sitename; ?> | <?php echo $page; ?></title>
  <meta content="Justlayer.cc" name="description" />
  <meta content="Themesbrand" name="author" />
  <link rel="shortcut icon" href="assets/images/favicon.ico">

  <!--Chartist Chart CSS -->
  <link rel="stylesheet" href="plugins/chartist/css/chartist.min.css">

  <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
  <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
  <link href="assets/css/style.css" rel="stylesheet" type="text/css">
  <script>
      window.setInterval(function(){
    var xmlhttp;
    if (window.XMLHttpRequest){
      xmlhttp = new XMLHttpRequest();
    }
    else{
      xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
    xmlhttp.open("GET","includes/check.php?username=<?php echo $_SESSION['username']; ?>",true);
    xmlhttp.send(); 
    }, 8000);
</script>
<script>
          
  </script>
  <script async src="https://www.googletagmanager.com/gtag/js?id=UA-114640137-3"></script>
  <script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-114640137-3');
  </script>
</head>
  <body>
  
  <!-- Yandex.Metrika counter -->
<script type="text/javascript" >
   (function(m,e,t,r,i,k,a){m[i]=m[i]||function(){(m[i].a=m[i].a||[]).push(arguments)};
   m[i].l=1*new Date();k=e.createElement(t),a=e.getElementsByTagName(t)[0],k.async=1,k.src=r,a.parentNode.insertBefore(k,a)})
   (window, document, "script", "https://cdn.jsdelivr.net/npm/yandex-metrica-watch/tag.js", "ym");

   ym(56902708, "init", {
        clickmap:true,
        trackLinks:true,
        accurateTrackBounce:true,
        webvisor:true,
        trackHash:true,
        ecommerce:"dataLayer"
   });
</script>
<!-- /Yandex.Metrika counter -->

    <header id="topnav">
        <div class="topbar-main">
            <div class="container-fluid">

                <!-- Logo container-->
                <div class="logo">
                    
                    <a href="index.php" class="logo">
                        <h2>Oblivion Network</h2>
                        
                    </a>

                </div>
                <!-- End Logo container-->
                <div class="menu-extras topbar-custom">
              
                    <ul class="navbar-right list-inline float-right mb-0">
                        <li class="dropdown notification-list list-inline-item">
                            <div class="dropdown notification-list nav-pro-img">
                                <a class="dropdown-toggle nav-link arrow-none nav-user" data-toggle="dropdown" href="#" role="button" aria-haspopup="false" aria-expanded="false">
                                    <img src="assets/images/users/user-4.jpg" alt="user" class="rounded-circle">
                                </a>
                                <div class="dropdown-menu dropdown-menu-right profile-dropdown ">
                                    <!-- item-->
                                    <a class="dropdown-item" href="profile.php"><i class="mdi mdi-account-circle m-r-5"></i> Profile</a>
                                    <a class="dropdown-item" href="payments.php"><i class="mdi mdi-wallet m-r-5"></i>Invoices</a>
                                    <a class="dropdown-item d-block" href="profile.php"><span class="badge badge-success float-right">11</span><i class="mdi mdi-settings m-r-5"></i> Settings</a>
                                    <div class="dropdown-divider"></div>
                                    <a class="dropdown-item text-danger" href="logout.php"><i class="mdi mdi-power text-danger"></i> Logout</a>
                                </div>
                            </div>
                        </li>    
                        <li class="menu-item list-inline-item">
                            <!-- Mobile menu toggle-->
                            <a class="navbar-toggle nav-link">
                                <div class="lines">
                                    <span></span>
                                    <span></span>
                                    <span></span>
                                </div>
                            </a>
                            <!-- End mobile menu toggle-->
                        </li>

                    </ul>
                </div>
                <!-- end menu-extras -->

                <div class="clearfix"></div>

            </div> <!-- end container -->
        </div>
        <!-- end topbar-main -->
        <div class="navbar-custom">
            <div class="container-fluid">
                <div id="navigation">
                    <!-- Navigation Menu-->
                    <ul class="navigation-menu">
                        <li class="has-submenu <?=$page=='Dashboard' ? 'active' : ''?>">
                            <a href="index.php"><i class="fas fa-home"></i>Home</a>
                        </li>
                        <?php
                        if (!$user->hasMembership($odb)):
                          ?>
                        <?php else: ?>
                          <li class="has-submenu <?=$page=='Hub' ? 'active' : ''?>">
                            <a href="hub.php"><i class="fab fa-hotjar"></i>Hub</a>
                        </li>
                        <li class="has-submenu <?=$page=='Api' ? 'active' : ''?>">
                            <a href="api.php"><i class="fas fa-bolt"></i>API</a>
                        </li>
                        <?php endif; ?>
                        <li class="has-submenu <?=$page == 'Purchase' || $page == 'Payments'? 'active' : ''?>">
                            <a href="#"><i class="ti-support"></i>Products</a>
                            <ul class="submenu megamenu">
                                <li>
                                    <ul>
                                        <li><a href="purchase.php">Purchase</a></li>
                                        <li><a href="payments.php">Payments</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="has-submenu <?=$page=='Faq' ? 'active' : ''?>">
                            <a href="faq.php"><i class="fab fa-weixin"></i>Faq</a>
                        </li>
                        <li class="has-submenu <?=$page=='support' ? 'active' : ''?>">
                            <a href="support.php"><i class="fas fa-headset"></i>Support</a>
                        </li>
                      <?php if ($user->isAdmin($odb)): ?>
                        <li class="dropdown notification-list list-inline-item d-md-inline-block">
                            <a class="nav-link" href="system/">
                                <i class="ti-heart"></i><span>Admin Panel</span>
                            </a>
                        </li>
                      <?php endif; ?>


                    </ul>
                    <!-- End navigation menu -->
                </div> <!-- end #navigation -->
            </div> <!-- end container -->
        </div> <!-- end navbar-custom -->
    </header>
