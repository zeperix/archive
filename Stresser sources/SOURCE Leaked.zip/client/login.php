<?php
include_once __DIR__ . "/reGuard.php";
?>
<?php

ob_start();
require_once 'rip/configuration.php';
require_once 'rip/init.php';

  if ($user -> LoggedIn()){
header('Location: index.php');
exit;
}
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
        <meta name="keywords" content="IP Stresser,Booter,Web Booter,free stresser,free ddos,ovh down,game down,ts3 ddos,ts3 down,stresser,free ip stresser">
  <meta name="description" content="Create a free account to test our plans up to 200 gbps. The best free ip stresser service on the market!" />
        <title>Oblivion | Login</title>
        <meta content="Oblivion Login" name="description" />
        <meta content="Oblivion" name="author" />
        <link rel="shortcut icon" href="assets/images/favicon.ico">

        <link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="assets/css/icons.css" rel="stylesheet" type="text/css">
        <link href="assets/css/style.css" rel="stylesheet" type="text/css">
    </head>

    <body class="pb-0">

        <div class="home-btn d-none d-sm-block">
            <a href="index.php" class="text-white"></a>
        </div>
        
        <div class="wrapper-page">

            <div class="card overflow-hidden account-card mx-3">
                <style>
label, input {
    display: block;
}

input {
    margin-bottom: 20px;
}
</style>
                <div class="bg-primary p-4 text-white text-center position-relative">
                    <h4 class="font-20 m-b-5">Welcome Back!</h4>
                    <p class="text-white-50 mb-4">Sign in to continue to Oblivion.</p>
                    <a class="logo logo-admin"><img src="assets/images/avatar.png" height="80" alt="logo"></a>
                </div>
                <div class="account-card-content"> 

                    <form class="form-horizontal m-t-30" onsubmit="return false">
                    <div id="alert" style="display:none"></div>
                        <div class="form-group">
                            <label for="username">Username</label>
                            <input type="text" class="form-control" id="username" placeholder="Enter username" onkeydown="if (event.keyCode == 13) document.getElementById('login').click()>
                        </div>
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" id="password" placeholder="Enter password" onkeydown="if (event.keyCode == 13) document.getElementById('login').click()>
                        </div>

                        <div class="form-group row m-t-20">
                            <div class="col-sm-12 d-flex justify-content-center mt-4">
                                <button class="btn btn-primary w-md waves-effect waves-light" id="login">Log In</button>
                            </div>
                        </div>
                        <div class="form-group m-t-10 mb-0 row">
                            <div class="col-12 m-t-20">
                                 <p>Don't have an account? <a href="register.php" class="font-500 text-primary"> Signup now!</a></p>
                            </div>
                           </div> 
                        </div
                    </form>
                </div>
            </div>

        </div>
        <!-- end wrapper-page -->

        <!-- jQuery  -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/bootstrap.bundle.min.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/waves.min.js"></script>

        <!-- App js -->
        <script src="assets/js/app.js"></script>
        <script>
        $(function(){
          $("#password").keyup(function(event){
            if(event.keyCode == 13){
                login();
            }
        });

        $('#login').on('click',function(){
          var user=$('#username').val();
          var password=$('#password').val();
          document.getElementById("alert").style.display="none";
          var xmlhttp;
          if (window.XMLHttpRequest)
            {
            xmlhttp=new XMLHttpRequest();
            }
          else
            {
            xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
            }
          xmlhttp.onreadystatechange=function()
            {
            if (xmlhttp.readyState==4 && xmlhttp.status==200)
              {
                
              if (xmlhttp.responseText.search("Login Successful") != -1)
              {
                window.location="index.php"
              }
            } else {
              document.getElementById("alert").innerHTML=xmlhttp.responseText;
                document.getElementById("alert").style.display="inline";
            }
          }
          xmlhttp.open("POST","includes/login.php?type=login",true);
          xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
          xmlhttp.send("user=" + user + "&password=" + password);
        })
        })
        </script>


    </body>

</html>