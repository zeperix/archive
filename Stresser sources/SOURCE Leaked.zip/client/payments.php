<?php require 'header.php'; ?>
<div class="wrapper">
    <div class="container-fluid">
      <div class="page-title-box">
          <div class="row align-items-center">
      
              <div class="col-sm-12">
              <ol class="breadcrumb">
                  <li class="breadcrumb-item active">Oblivion / Payments</li>
              </div>
          </div>
      </div>
      <div class="row">
        <div class="col-xl-3 col-md-6">
          <div class="card mini-stat bg-primary text-white">
              <div class="card-body">
                  <div class="mb-4">
                      <div class="float-left mini-stat-img mr-4">
                          <img src="assets/images/services-icon/01.png" alt="" >
                      </div>
                      <?php				
                        $SQL = $odb -> prepare("SELECT COUNT(*) FROM `payments` WHERE `username` = :username AND `status` = '0'");
                        $SQL -> execute(array(':username' => $_SESSION['username']));
                        $count = $SQL -> fetchColumn(0);
                      ?>
                      <h5 class="font-16 text-uppercase mt-0 text-white-50">Pending</h5>
                      <h4 class="font-500"><?=$count?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                  </div>
                  <div class="pt-2">
                     
                  </div>
              </div>
          </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card mini-stat bg-primary text-white">
                <div class="card-body">
                    <div class="mb-4">
                        <div class="float-left mini-stat-img mr-4">
                            <img src="assets/images/services-icon/01.png" alt="" >
                        </div>
                        <?php				
                          $SQL = $odb -> prepare("SELECT COUNT(*) FROM `payments` WHERE `username` = :username AND `status` = '1'");
                          $SQL -> execute(array(':username' => $_SESSION['username']));
                          $count = $SQL -> fetchColumn(0);
                        ?>
                        <h5 class="font-16 text-uppercase mt-0 text-white-50">Canceled</h5>
                        <h4 class="font-500"><?=$count?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                       
                    </div>
                    <div class="pt-2">
                        
                    </div>
                </div>
            </div>
          </div>
          <div class="col-xl-3 col-md-6">
              <div class="card mini-stat bg-primary text-white">
                  <div class="card-body">
                      <div class="mb-4">
                          <div class="float-left mini-stat-img mr-4">
                              <img src="assets/images/services-icon/01.png" alt="" >
                          </div>
                          <?php				
                            $SQL = $odb -> prepare("SELECT COUNT(*) FROM `payments` WHERE `username` = :username AND `status` = '2'");
                            $SQL -> execute(array(':username' => $_SESSION['username']));
                            $count = $SQL -> fetchColumn(0);
                          ?>
                          <h5 class="font-16 text-uppercase mt-0 text-white-50">Completed</h5>
                          <h4 class="font-500"><?=$count?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                          
                      </div>
                      <div class="pt-2">
                        
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card mini-stat bg-primary text-white">
                    <div class="card-body">
                        <div class="mb-4">
                            <div class="float-left mini-stat-img mr-4">
                                <img src="assets/images/services-icon/01.png" alt="" >
                            </div>
                            <?php				
                              $SQL = $odb -> prepare("SELECT COUNT(*) FROM `payments` WHERE `username` = :username");
                              $SQL -> execute(array(':username' => $_SESSION['username']));
                              $count = $SQL -> fetchColumn(0);
                            ?>
                            <h5 class="font-16 text-uppercase mt-0 text-white-50">All</h5>
                            <h4 class="font-500"><?=$count?> <i class="mdi mdi-arrow-up text-success ml-2"></i></h4>
                           
                        </div>
                        <div class="pt-2">
                           
                        </div>
                    </div>
                </div>
              </div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title mb-4">Latest Trasaction</h4>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                <th scope="col">(#) Id</th>
                                <th scope="col">Username</th>
                                <th scope="col">Status</th>
                                <th scope="col">Submitted</th>
                                <th scope="col" colspan="2">Ip Address</th>
                                <th scope="col" colspan="2">Plan</th>
                                <th scope="col" colspan="2">Value</th> 
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $newssql = $odb -> query("SELECT * FROM `payments` WHERE `username` = '" . $_SESSION['username'] . "'ORDER BY `id` DESC LIMIT 50");
                                while($row = $newssql ->fetch(PDO::FETCH_ASSOC)){
                                  if($row['status'] == '0') {
                                    $statusPayment = '<span class="badge badge-warning">Pending</span>';
                                  } elseif($row['status'] == '1') {
                                    $statusPayment = '<span class="badge badge-danger">Canceled</span>';
                                  } elseif($row['status'] == '2') {
                                    $statusPayment = '<span class="badge" style="background: linear-gradient(135deg, #262f38 0, #42a5f5 100%)!important;">Completed!</span>';
                                  }
                                  
                                  $Planinfo = $odb -> query("SELECT `name`,`price` FROM `plans` WHERE `id` = '" . $row['planID'] . "'");
                                $rowPlan = $Planinfo ->fetch(PDO::FETCH_ASSOC);
                                    ?>
                                <tr>
                                  <th scope="row"> <a href="invoice.php?id=<?= $row['planID']; ?>&invoice=<?= $row['invoiceID']; ?>">#<?=$row['invoiceID']?></a> </th>
                                  <td>
                                      <?=$row['username']?>
                                  </td>
                                  <td><?= $statusPayment; ?></td>
                                  <td><?= date("m/d/y - h:i:s", htmlentities($row['date'])); ?></td>
                                  <td>
                                      <a href="javascript:void(0)"><?= htmlentities($row['IP']); ?></a>
                                  </td>
                                  <td><?= $rowPlan['name']; ?></td>
                                  <td>$<?= $rowPlan['price']; ?></td>
                                </tr> 
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-xl-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title mb-4">Add Balance Logs</h4>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                <th scope="col">Username</th>
                                <th scope="col">Email</th>
                                <th scope="col">Method</th>
                                <th scope="col" colspan="2">Date</th>
                                <th scope="col" colspan="2">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                        $SQLGetMessages = $odb -> prepare("SELECT * FROM `addbalance` WHERE `username` = :username ORDER BY `id` DESC LIMIT 50");
                                        $SQLGetMessages -> execute(array(':username' => $_SESSION['username']));
                                        while ($show = $SQLGetMessages -> fetch(PDO::FETCH_ASSOC)){
                                        $username = $show['username'];
                                        $myemail = $show['email'];
                                        $method = $show['method'];
                                        $date =  $show['date'];  
										
										              if($show['status'] == '0') {
	                                     	$statusPayment = '<span class="badge badge-warning">Pending</span>';
		                                 } elseif($show['status'] == '1') {
	                                      	$statusPayment = '<span class="badge badge-danger">Canceled</span>';
		                                 } elseif($show['status'] == '2') {
		                                  	$statusPayment = '<span class="badge" style="background: linear-gradient(135deg, #262f38 0, #42a5f5 100%)!important;">Completed!</span>';
                                       }
                                       ?>
                                <tr>
                                  <th><?=$username?></th>
                                  <td>
                                      <?=$myemail ?>
                                  </td>
                                  <td><?= $method ?></td>
                                  <td><?= date("m/d/y - h:i:s", $date); ?></td>
                                  <td>
                                    <?=$statusPayment?>
                                  </td>
                                 
                                </tr> 
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>

<?php require 'footer.php'; ?>
